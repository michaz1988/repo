# -*- coding: UTF-8 -*-

#2021-02-24

import re
import json
import difflib
from scrapers.modules import cleantitle
from resources.lib.requestHandler import cRequestHandler

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        for title in titles:
        	if season > 0:
        		asin = self.episode(title, season, episode)
        		break
        	else:
        		asin = __search(title,year)
        		break
        sources.append({'source': 'AMAZON', 'quality': '1080p', 'language': 'de', 'url':'plugin://plugin.video.amazon-test/?asin='+asin +'&mode=PlayVideo' , 'info': '', 'direct': True, 'debridonly': False})
        return sources

    def __search(self, title,year):        
        title=cleantitle.getsearch(title)
        
        query="https://atv-ps-eu.amazon.de/cdp/catalog/Search?firmware=fmw:17-app:2.0.45.1210&deviceTypeID=A2M4YX06LWP8WI&deviceID=1&format=json&version=2&formatVersion=3&marketplaceId=A1PA6795UKMFR9&IncludeAll=T&AID=1&searchString="+str(title)+"&NumberOfResults=10&StartIndex=0&Detailed=T"
      
        #data = requests.get(query).json()
        data  = json.loads(cRequestHandler(query).request())
        

        streams = []
        for i in data['message']['body']['titles']:            
            stream = {'amazontitle' : '', 'ratio' : '', 'asin' : ''}
            try:
                amazontitle =re.sub("\[dt.\/OV\]","",str(i['title']))                
                amazontitle = unicode(cleantitle.getsearch(amazontitle))                
                ratio=difflib.SequenceMatcher(None, title, amazontitle).ratio()                
                amazonyear = int(str(i['releaseOrFirstAiringDate']['valueFormatted'])[0:4])
                year = int(year)                
                year_ok = False
                for x in range(year-1, year+2):
                    if amazonyear == x:
                        year_ok = True
                stream['amazontitle'] = amazontitle
                stream['ratio'] = ratio
            except:
                continue

            # Der Ratio benötigt ein minimal Wert,da ansosnten ein xbeliebiger ander match genommen wird
            if float(stream['ratio']) > float(0.5):
                
                prime=i['formats'][0]['offers'][0]['offerType']
                                
                if prime == "SUBSCRIPTION":                    
                    asin = i['titleId']
                    stream['asin'] = asin
                else:
                    continue;
                
                if year_ok == True:                    
                    streams.append(stream)
            else:
                continue                
        
        streams = sorted(streams, key = lambda i: i['ratio'])        
        best_asin = streams[len(streams)-1]['asin']        
        return best_asin

    def episode(self, title, season, episode):
            
        title=cleantitle.getsearch(title)
        url="https://atv-ps-eu.amazon.de/cdp/catalog/Search?firmware=fmw:17-app:2.0.45.1210&deviceTypeID=A2M4YX06LWP8WI&deviceID=1&format=json&version=2&formatVersion=3&marketplaceId=A1PA6795UKMFR9&IncludeAll=T&AID=1&searchString="+title+"&OfferGroups=B0043YVHMY&SuppressBlackedoutEST=T&NumberOfResults=40&StartIndex=0"

        #data = requests.get(url).json()
        data  = json.loads(cRequestHandler(url).request())
       
        for i in data['message']['body']['titles']:
            
            ## Titel abgleich ##
            try:
                #print "print AP episode local title VS. amazon clena title", localtitle,cleantitle.getsearch(str(i['ancestorTitles'][0]['title']))
                #amazontitle =re.sub("\[dt.\/OV\]","",str(i['title']))
                ## try-block weil ChildTitles manchmal leeres ergebnis liefern
                if title in cleantitle.getsearch(str(i['ancestorTitles'][0]['title'])) and not "[ov]" in cleantitle.getsearch(str(i['ancestorTitles'][0]['title'])):
                    #print "print AP TvSow Title found!"
                    ## Season abgleich ##
                    #print "print AP str(season) == str(i['number']", str(season), str(i['number'])
                    try:
                        if str(season) == str(i['number']):
                            #print "print AP TRY S VS S"
                            easin=str(i['childTitles'][0]['feedUrl'])
                            break;
                    except:
                            easin="ERROR"                    
            except:
                continue
        
        ## if notempty ##
        if easin:            
            url="https://atv-ps-eu.amazon.de/cdp/catalog/Browse?firmware=fmw:17-app:2.0.45.1210&deviceTypeID=A2M4YX06LWP8WI&deviceID=d24ff55e99d2e8d6353cd941f9f63fbb3d242b92576e09b6b8a90660&format=json&version=2&formatVersion=3&marketplaceId=A1PA6795UKMFR9&"+easin
            #data = requests.get(url).json()
            data  = json.loads(cRequestHandler(url).request())
            
            for i in data['message']['body']['titles']:
            
            ## Titel abgleich ##
                try:
                    ## try-block weil ChildTitles manchmal leeres ergebnis liefern
                    prime=i['formats'][0]['offers'][0]['offerType']
                    
                    if prime == "SUBSCRIPTION":
                        #print "print AP Prime Subrsciption",prime
                        if str(episode)==str(i['number']):
                            #print "print Title/EpisodeMAthc "
                            videoid=i['titleId']
                            break;
                except:
                    continue

            return videoid
        else:
            return


    def resolve(self, url):
        try:
            return url
        except:
            return
