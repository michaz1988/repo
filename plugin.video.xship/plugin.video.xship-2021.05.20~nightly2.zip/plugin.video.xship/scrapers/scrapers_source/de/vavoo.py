# -*- coding: UTF-8 -*-
import requests, difflib
from resources.lib.control import urljoin
from scrapers.modules import cleantitle, source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['vjackson.info']
        self.base_link = 'http://vjackson.info'
        self.search_link = '/all'
        self.signatur = self._getSignatur()

    def _getSignatur(self):
        vec = {"vec": "9frjpxPjxSNilxJPCJ0XGYs6scej3dW/h/VWlnKUiLSG8IP7mfyDU7NirOlld+VtCKGj03XjetfliDMhIev7wcARo+YTU8KPFuVQP9E2DVXzY2BFo1NhE6qEmPfNDnm74eyl/7iFJ0EETm6XbYyz8IKBkAqPN/Spp3PZ2ulKg3QBSDxcVN4R5zRn7OsgLJ2CNTuWkd/h451lDCp+TtTuvnAEhcQckdsydFhTZCK5IiWrrTIC/d4qDXEd+GtOP4hPdoIuCaNzYfX3lLCwFENC6RZoTBYLrcKVVgbqyQZ7DnLqfLqvf3z0FVUWx9H21liGFpByzdnoxyFkue3NzrFtkRL37xkx9ITucepSYKzUVEfyBh+/3mtzKY26VIRkJFkpf8KVcCRNrTRQn47Wuq4gC7sSwT7eHCAydKSACcUMMdpPSvbvfOmIqeBNA83osX8FPFYUMZsjvYNEE3arbFiGsQlggBKgg1V3oN+5ni3Vjc5InHg/xv476LHDFnNdAJx448ph3DoAiJjr2g4ZTNynfSxdzA68qSuJY8UjyzgDjG0RIMv2h7DlQNjkAXv4k1BrPpfOiOqH67yIarNmkPIwrIV+W9TTV/yRyE1LEgOr4DK8uW2AUtHOPA2gn6P5sgFyi68w55MZBPepddfYTQ+E1N6R/hWnMYPt/i0xSUeMPekX47iucfpFBEv9Uh9zdGiEB+0P3LVMP+q+pbBU4o1NkKyY1V8wH1Wilr0a+q87kEnQ1LWYMMBhaP9yFseGSbYwdeLsX9uR1uPaN+u4woO2g8sw9Y5ze5XMgOVpFCZaut02I5k0U4WPyN5adQjG8sAzxsI3KsV04DEVymj224iqg2Lzz53Xz9yEy+7/85ILQpJ6llCyqpHLFyHq/kJxYPhDUF755WaHJEaFRPxUqbparNX+mCE9Xzy7Q/KTgAPiRS41FHXXv+7XSPp4cy9jli0BVnYf13Xsp28OGs/D8Nl3NgEn3/eUcMN80JRdsOrV62fnBVMBNf36+LbISdvsFAFr0xyuPGmlIETcFyxJkrGZnhHAxwzsvZ+Uwf8lffBfZFPRrNv+tgeeLpatVcHLHZGeTgWWml6tIHwWUqv2TVJeMkAEL5PPS4Gtbscau5HM+FEjtGS+KClfX1CNKvgYJl7mLDEf5ZYQv5kHaoQ6RcPaR6vUNn02zpq5/X3EPIgUKF0r/0ctmoT84B2J1BKfCbctdFY9br7JSJ6DvUxyde68jB+Il6qNcQwTFj4cNErk4x719Y42NoAnnQYC2/qfL/gAhJl8TKMvBt3Bno+va8ve8E0z8yEuMLUqe8OXLce6nCa+L5LYK1aBdb60BYbMeWk1qmG6Nk9OnYLhzDyrd9iHDd7X95OM6X5wiMVZRn5ebw4askTTc50xmrg4eic2U1w1JpSEjdH/u/hXrWKSMWAxaj34uQnMuWxPZEXoVxzGyuUbroXRfkhzpqmqqqOcypjsWPdq5BOUGL/Riwjm6yMI0x9kbO8+VoQ6RYfjAbxNriZ1cQ+AW1fqEgnRWXmjt4Z1M0ygUBi8w71bDML1YG6UHeC2cJ2CCCxSrfycKQhpSdI1QIuwd2eyIpd4LgwrMiY3xNWreAF+qobNxvE7ypKTISNrz0iYIhU0aKNlcGwYd0FXIRfKVBzSBe4MRK2pGLDNO6ytoHxvJweZ8h1XG8RWc4aB5gTnB7Tjiqym4b64lRdj1DPHJnzD4aqRixpXhzYzWVDN2kONCR5i2quYbnVFN4sSfLiKeOwKX4JdmzpYixNZXjLkG14seS6KR0Wl8Itp5IMIWFpnNokjRH76RYRZAcx0jP0V5/GfNNTi5QsEU98en0SiXHQGXnROiHpRUDXTl8FmJORjwXc0AjrEMuQ2FDJDmAIlKUSLhjbIiKw3iaqp5TVyXuz0ZMYBhnqhcwqULqtFSuIKpaW8FgF8QJfP2frADf4kKZG1bQ99MrRrb2A="}
        return requests.post('https://www.vavoo.tv/api/box/ping2', vec).json()['response'].get('signed')

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict =None):
    	if season == 0:
    		return self.sources(self.movie(imdb, titles, year), hostDict)
    	else:
    		return self.sources(self.tvshow(imdb, titles, year), hostDict, season, episode)
    			
    def movie(self, imdb, titles, year):
        s = [] 
        for title in titles:
            params={"type": "movie", "year": year, "locale": 'de', "language": 'de', "resolutions": "all", "query": title}
            data = requests.get(urljoin(self.base_link, self.search_link), params).json()
            for i in data:
                if i.get('original_title'):newtitle = i['original_title'].lower()
                else:newtitle = i['title'].lower()
                if str(imdb) == str(i['imdb']) or float(difflib.SequenceMatcher(None, title, newtitle).ratio()) > float(0.4):
                	if str(i['id']) not in s:
                  	  s.append(str(i['id']))
        return s
                
    def tvshow(self, imdb, titles, year):
        s = []
        for title in titles:
            params={"type": "serie", "locale": 'de', "language": 'de', "resolutions": "all", "query": title}
            data = requests.get(urljoin(self.base_link, self.search_link), params).json()
            for i in data:
                if (imdb) == str(i['imdb']) or float(difflib.SequenceMatcher(None, title, i['title'].lower()).ratio()) > float(0.6):
                	if str(i['id']) not in s:
                  	  s.append(str(i['id']))
        return s

    def sources(self, url, hostDict, season=0, episode=0):
        sources = []
        try:
            if not url:
                return sources
            for id in url:
                if season==0:
                    params = {'id': id, 'vavoo_auth': self.signatur, 'language' : 'de' , 'locale': 'de', "resolutions": "all"}
                else: params = {'id': id, 'season': season, 'episode': episode, 'vavoo_auth': self.signatur, 'language' : 'de' , 'locale': 'de', "resolutions": "all"}
                data = requests.get(urljoin(self.base_link, '/get'),params).json()['get']['links']
                for i in range(len(data)):
                    if data[i]['parts'] == 1:
                        if season==0: params = {'id': id, 'vavoo_auth': self.signatur, 'language' : 'de' , 'hoster': data[i]['hoster'], 'parts': data[i]['parts'], 'quality': data[i]['quality'], 'resolution': data[i]['resolution'], 'subtitles': data[i]['subtitles']}
                        else:params = {'id': id, 'season': season, 'episode': episode, 'vavoo_auth': self.signatur, 'language' : 'de' , 'hoster': data[i]['hoster'], 'parts': data[i]['parts'], 'quality': data[i]['quality'], 'resolution': data[i]['resolution'], 'subtitles': data[i]['subtitles']}
                        if data[i]['resolution'] == 'hd': resolution = '720p'
                        else:resolution = "SD"
                        link=requests.get(urljoin(self.base_link, '/link'),params).json()['parts']['1']
                        valid, host = source_utils.is_host_valid(link, hostDict)
                        if valid: sources.append({'source': data[i]['hoster'], 'quality': resolution, 'language': 'de', 'url': link, 'direct': False, 'debridonly': False})
            
            return sources
        except:
            return sources
   
    def resolve(self, url):
        return url