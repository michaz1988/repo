# -*- coding: UTF-8 -*-

# 2021-05-14

from scrapers.modules.tools import cParser  # re - alternative
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils

# kkiste
class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['kkiste.movie']
        self.base_link = 'https://kkiste.movie'
        self.base_link = source_utils.check_302(self.base_link)
        self.search_link = self.base_link + '/index.php?do=search'

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        url = ''
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            years = (year, year+1, year-1, 0)
            links = []
            for sSearchText in titles:
                try:
# do=search&subaction=search&search_start=0&full_search=1&result_from=1&story=blindspot&titleonly=3&searchuser=&titleonly=0&replyless=0&replylimit=0&searchdate=0&beforeafter=after&sortby=date&resorder=desc&showposts=0&catlist%5B%5D=34
                    oRequest = cRequestHandler(self.search_link)
                    oRequest.addParameters('do', 'search')
                    oRequest.addParameters('subaction', 'search')
                    oRequest.addParameters('search_start', '0')
                    oRequest.addParameters('full_search', '0')
                    oRequest.addParameters('result_from', '1')
                    oRequest.addParameters('story', sSearchText)
                    oRequest.addParameters('titleonly', '3')
                    sHtmlContent = oRequest.request()
                    r = dom_parser.parse_dom(sHtmlContent, 'div', attrs={'id': 'dle-content'})[0].content

                    pattern = 'h2>.*?href="([^"]+)">([^<]+).*?label-1">([^<]+).*?(\d{4})<'
                    isMatch, aResult = cParser.parse(r, pattern)
                    if not isMatch:
                        continue

                    for sUrl, sName, sQuality, sYear in aResult:
                        if season == 0:
                            if cleantitle.get(sName) in t and int(sYear) in years:
                                  links.append({'url': sUrl,'name': sName, 'quality': sQuality, 'year': sYear})
                        else:
                            if cleantitle.get(sName.split('-')[0].strip()) in t and str(season) in sName.split('-')[1]:
                                links.append({'url': sUrl, 'name': sName.split('-')[0].strip(), 'quality': sQuality, 'year': sYear})

                    if len(links) > 0: break
                except:
                    continue

            if len(links) == 0: return sources

            for link in links:
                sHtmlContent = cRequestHandler(link['url']).request()
                if season > 0:
                    pattern = '\s%s<.*?</ul>' % episode
                    isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
                    if not isMatch: return sources

                isMatch, aResult = cParser().parse(sHtmlContent, 'link="([^"]+)">')

                if isMatch:
                    for sUrl in aResult:
                        if sUrl.startswith('/'): sUrl = 'https:' + sUrl
                        valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                        if not valid or 'youtube'in hoster: continue
                        sources.append({'source': hoster, 'quality': link['quality'], 'language': 'de', 'url': sUrl, 'direct': False})

            return sources
        except:
            return sources

    def resolve(self, url):
        try:
            return url
        except:
            return
