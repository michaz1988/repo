import re, traceback

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from playscrapers.modules import cleantitle
from playscrapers.modules import client
from playscrapers.modules import dom_parser
from playscrapers.modules import source_utils


def getPlaylistLinks(url):
    hdgoContent = client.request(url)
    playlistLink = dom_parser.parse_dom(hdgoContent, 'iframe')
    if len(playlistLink) > 0:
        playlistLink = playlistLink[0].attrs['src']
        playListContent = client.request('http:' + playlistLink)
        links = re.findall('\[(".*?)\]', playListContent, re.DOTALL)
        links = links[0].split(',')
        links = [i.replace('"', '').replace('\r\n','').replace('/?ref=hdgo.cc', '') for i in links]
        return [urljoin('http://hdgo.cc', i) for i in links]
    return

def getStreams(url, sources, quality, skiplast=True, quali="HD"):
    if quality is not None:
        quali=quality
    if 'hdgo' in url:
        hdgostreams = getHDGOStreams(url)
        if hdgostreams is not None:
            if len(hdgostreams) > 1 and skiplast:
                hdgostreams.pop(0)
            quality = ["SD", "HD", "1080p", "2K", "4K"]
            for i, stream in enumerate(hdgostreams):
                sources.append({'source': 'hdgo.cc', 'quality': quality[i], 'language': 'de',
                                'url': stream + '|Referer=' + url, 'direct': True,
                                'debridonly': False})
    elif 'streamz' in url:
        streamzstream = getstreamzStreams(url)
        if streamzstream is not None:
            stream = client.request(streamzstream, output='geturl')
            sources.append({'source': 'streamz.cc', 'quality': quali, 'language': 'de',
                            'url': stream, 'direct': True,
                            'debridonly': False})
    elif 'vio' in url:
        Viotreams = getViotreams(url)
        if Viotreams is not None:
            if len(Viotreams) > 1 and skiplast:
                Viotreams.pop(0)
            quality = ["SD", "HD", "1080p", "2K", "4K"]
            for i, stream in enumerate(Viotreams):
                sources.append({'source': 'vio', 'quality': quality[i], 'language': 'de',
                                'url': stream + '|Referer=' + url, 'direct': True,
                                'debridonly': False})
    elif 'vivo.php' in url:
        vivostream = getvivo_php_Streams(url)
        if vivostream is not None:
            stream = client.request(vivostream, output='geturl')
            sources.append({'source': 'vivo', 'quality': quali, 'language': 'de',
                            'url': stream, 'direct': True,
                            'debridonly': False})
    return sources


def getHDGOStreams(url):
    try:
        request = client.request(url, referer=url)
        request = dom_parser.parse_dom(request, 'iframe')[0].attrs['src']
        request = client.request(urljoin('http://', request), referer=url)
        request = re.findall("media:\s(\[.*?\])", request, re.DOTALL)[0]
        request = re.findall("'(.*?\')", request)
        return ["https:" + i.replace("'", "") for i in request if i[:2] == "//"]
    except:
        return None

def getViotreams(url):
    try:
        request = client.request(url, referer=url)
        request = re.findall(r'{url: \'(.*?)\'', request)
        return ["https:" + i.replace("'", "") for i in request if i[:2] == "//"]
    except:
        return None

def getstreamzStreams(url):
    try:
        request = client.request(url, referer=url)
        request = re.findall(r'{src: \'(.*?)\',type', request)[0]
        return request
    except:
        return None

def getvivo_php_Streams(url):
    try:
        request = client.request(url, referer=url)
        request = re.findall(r'<video\s*id="player"[^>]+data-stream="([^"]+)', request)
        return request[0].decode('base64')
    except:
        return None


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['filmpalast.to']
        self.base_link = 'http://filmpalast.to'
        self.search_link = '/search/title/%s'
        self.stream_link = 'stream/%s/1'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search(
                False, [localtitle] + source_utils.aliases_to_array(aliases), False)
            if not url and title != localtitle:
                url = self.__search(False, [title] + source_utils.aliases_to_array(aliases), False)
            if not url:
                url = self.__search(False, [title] + source_utils.aliases_to_array(aliases), True)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search(
                True, [localtvshowtitle] + source_utils.aliases_to_array(aliases), False)
            if not url and tvshowtitle != localtvshowtitle:
                url = self.__search(
                    True, [tvshowtitle] + source_utils.aliases_to_array(aliases), False)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            episode = '0' + episode if int(episode) < 10 else episode
            season = '0' + season if int(season) < 10 else season

            return re.findall('(.*?)s\d', url)[0] + 's%se%s' % (season, episode)
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources

            query = urljoin(self.base_link, url)
            r = client.request(query, referer=self.base_link, redirect=True)
            quality = dom_parser.parse_dom(r, 'span', attrs={'id': 'release_text'})[
                0].content.split('&nbsp;')[0]
            quality, info = source_utils.get_release_quality(quality)
            r = dom_parser.parse_dom(
                r, 'ul', attrs={'class': 'currentStreamLinks'})
            r = [(dom_parser.parse_dom(i, 'p', attrs={'class': 'hostName'}), re.findall(
                r'(http[^"]+)', i.content)) for i in r]
            r = [(re.sub('\shd', '', i[0][0].content.lower()), i[1][0])
                 for i in r if i[0] and i[1]]

            for hoster, id in r:
                valid, hoster = source_utils.is_host_valid(hoster, hostDict)
                if valid:
                    sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'info': '',
                                    'url': id, 'direct': False, 'debridonly': False, 'checkstreams': True})
                else:
                    if 'vivo.php' in id:
                        sources = getStreams(id, sources, quality)
            if len(sources) == 0:
                raise Exception()
            return sources
        except:
            return sources
            

    def resolve(self, url):
        return str(url)

    def __search(self, isSerieSearch, titles, isTitleClean):
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            if isTitleClean:
                t = [cleantitle.get(self.titleclean(i)) for i in set(titles) if i]
            for title in titles:
                if isTitleClean:
                    title = self.titleclean(title)
                query = self.search_link % (quote_plus(title))
                query = urljoin(self.base_link, query)
                r = client.request(query, referer=self.base_link, redirect=True)
                r = dom_parser.parse_dom(r, 'article')
                r = dom_parser.parse_dom(r, 'a', attrs={'class': 'rb'}, req='href')
                r = [(i.attrs['href'], i.content) for i in r]

                if len(r) > 0:

                    if isSerieSearch:
                        r = [i[0] for i in r if cleantitle.get(i[1]) in t and not isSerieSearch or cleantitle.get(
                            re.findall('(.*?)S\d', i[1])[0]) and isSerieSearch]

                    else:
                        r = [i[0] for i in r if cleantitle.get(
                            i[1]) in t and not isSerieSearch]

                    if len(r) > 0:
                        url = source_utils.strip_domain(r[0])
                        return url

            return
        except:
            return

    def titleclean(self, title):
        if title is None:
            return
        for i in (':', '!', '!', '!'):  # '!' Platzhalter für weiteres
            if i in title:
                title = title.replace(i, '')
                return title
        if 'II' in title:
            title = title.replace('II', '2')
        elif 'III' in title:
            title = title.replace('III', '3')
        elif 'IV' in title:
            title = title.replace('IV', '4')

        return title