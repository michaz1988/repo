# -*- coding: UTF-8 -*-

"""
    Lastship Add-on (C) 2019
    Credits to Lastship, Placenta and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Addon Name: Lastship
# Addon id: plugin.video.lastship
# Addon Provider: Lastship

import base64, binascii, re, hashlib, json
from playscrapers.modules import pyaes
from playscrapers.modules import dom_parser
from playscrapers.modules import source_utils
from playscrapers.modules.handler.requestHandler import cRequestHandler

class cUtil:
    @staticmethod
    def evp_decode(cipher_text, passphrase, salt=None):
        if not salt:
            salt = cipher_text[8:16]
            cipher_text = cipher_text[16:]
        key, iv = cUtil.evpKDF(passphrase, salt)
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv))
        plain_text = decrypter.feed(cipher_text)
        plain_text += decrypter.feed()
        return plain_text.decode("utf-8")

    @staticmethod
    def evpKDF(pwd, salt, key_size=32, iv_size=16):
        temp = b''
        fd = temp
        while len(fd) < key_size + iv_size:
            h = hashlib.md5()
            h.update(temp + pwd + salt)
            temp = h.digest()
            fd += temp
        key = fd[0:key_size]
        iv = fd[key_size:key_size + iv_size]
        return key, iv

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['hd-streams.org']
        self.base_link = 'https://hd-streams.org'
        self.movie_link = self.base_link + '/movies?perPage=54'
        self.movie_link = self.base_link + '/seasons?perPage=54'
        self.search = self.base_link + '/search?q=%s&movies=true&seasons=true&actors=true&didyoumean=true&extended=true'
        self.token = self._getToken('<meta name="csrf-token" content="([^"]+)">')

    def _getToken(self, pattern):
        sHtmlContent = cRequestHandler(self.base_link).request()
        return re.compile(pattern, flags=re.I | re.M).findall(str(sHtmlContent))[0]

    def movie(self, imdb, title, localtitle, aliases, year):
        objects = self.__search(imdb, True)
        return objects[1]['url']
            

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        objects = self.__search(imdb, False)
        return objects[1]['seasons']

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = [i['url'] for i in url if 'season/' + season in i['url']]

            return url[0], episode
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources

            if isinstance(url, tuple):
                url, episode = url
            oRequest = cRequestHandler(url)
            oRequest.removeBreakLines(False)
            oRequest.removeNewLines(False)
            r = oRequest.request()

            if "serie" in url:
                links = self._getSeriesLinks(r, episode)
            else:
                links = self._getMovieLinks(r)

            for e, h, sName, quali in links:
                valid, hoster = source_utils.is_host_valid(sName, hostDict)
                if not valid: continue

                stream = self.__getlinks(e, h, url)
                sources.append({'source': hoster, 'quality': quali, 'language': 'de', 'url': stream, 'info': "", 'direct': False, 'debridonly': False})
            if len(sources) == 0:
            	raise Exception()
            return sources
        except:
            return sources
            

    def __getlinks(self, e, h, url):
        oRequest = cRequestHandler(url + '/stream')
        oRequest.addHeaderEntry('X-CSRF-TOKEN', self.token)
        oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oRequest.addHeaderEntry('Referer', url)
        oRequest.addParameters('e', e)
        oRequest.addParameters('h', h)
        oRequest.addParameters('grecaptcha', '')
        sHtmlContent = oRequest.request()
        Data = json.loads(sHtmlContent)
        tmp = Data.get('d', '') + Data.get('c', '') + Data.get('iv', '') + Data.get('f', '') + Data.get('h', '') + Data.get('b', '')
        tmp = json.loads(base64.b64decode(tmp))
        salt = binascii.unhexlify(tmp['s'])
        ciphertext = base64.b64decode(tmp['ct'][::-1])
        b = base64.b64encode(self.token[::-1].encode('utf-8'))
        tmp = cUtil.evp_decode(ciphertext, b, salt)
        tmp = json.loads(base64.b64decode(tmp))
        ciphertext = base64.b64decode(tmp['ct'][::-1])
        salt = binascii.unhexlify(tmp['s'])
        b = ''
        a = self.token
        for idx in range(len(a) - 1, 0, -2): b += a[idx]
        if Data.get('e', None): b += '1'
        else: b += '0'
        tmp = cUtil.evp_decode(ciphertext, b.encode('utf-8'), salt)
        return json.loads(tmp)

    def resolve(self, url):
        return url

    def __search(self, imdb, isMovieSearch):
        try:
            if len(self.token) == 0:
                return #No Entry found?
            # first iteration of session object to be parsed for search
            oRequest = cRequestHandler(self.search % imdb)
            oRequest.removeBreakLines(False)
            oRequest.removeNewLines(False)
            oRequest.addHeaderEntry('X-CSRF-TOKEN', self.token)
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            sHtmlContent = oRequest.request()
            
            content = json.loads(sHtmlContent)
            if isMovieSearch:
                returnObjects = content["movies"]
            else:
                returnObjects = content["series"]

            return returnObjects
        except:
            return

    def _getMovieLinks(self, content):
        links = dom_parser.parse_dom(content, "v-tabs")
        links = [i for i in links if 'alt="de"' in dom_parser.parse_dom(i, "v-tab")[0].content]
        links = dom_parser.parse_dom(links, "v-tab-item")
        links = dom_parser.parse_dom(links, "v-flex")
        links = [dom_parser.parse_dom(i, "v-btn") for i in links]
        links = [[(a.attrs["@click"], re.findall("\n(.*)", a.content)[0].strip(), i[0].content) for a in i if
                  "@click" in a.attrs] for i in links]
        links = [item for sublist in links for item in sublist]
        links = [(re.findall("\d+", i[0]), i[1], i[2]) for i in links]
        return [(i[0][0], i[0][1], i[1], i[2]) for i in links]

    def _getSeriesLinks(self, content, episode):
        links = dom_parser.parse_dom(content, "div", attrs={'class': "episode"})
        links = [(dom_parser.parse_dom(i, "v-list-item"), dom_parser.parse_dom(i, "p", attrs={'class': "episode-number"})[0]) for i in links]
        links = [i[0] for i in links if episode == re.findall("\d+", i[1].content)[0]][0]
        links = [(a.attrs["@click.native"], dom_parser.parse_dom(a.content, 'v-list-item-title')[0].content) for a in links]
        links = [(re.findall("'(.*?)'", i[0]), i[1]) for i in links]
        return [(i[0][0], i[0][1], re.findall("(.*?)\d", i[1])[0].strip(), i[0][2]) for i in links]