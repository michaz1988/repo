# -*- coding: UTF-8 -*-

# Addon Name: PressPlay
# Addon id: plugin.video.pressplay
# Addon Provider: PressPlay

from playscrapers.modules import source_utils
from playscrapers.modules.handler.requestHandler import cRequestHandler
from playscrapers.modules.tools import cParser

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['kkiste.green']
        self.base_link = 'https://kkiste.green'

    def movie(self, imdb, title, localtitle, aliases, year):
        titles = source_utils.get_titles_for_search(title, localtitle, aliases)
        url = self.__search(titles, year)
        if url:
            return url
        return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            return {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'localtvshowtitle': localtvshowtitle,
                    'aliases': aliases, 'year': year}
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url: return
            data = url
            titles = source_utils.get_titles_for_search(data['tvshowtitle'], data['localtvshowtitle'], data['aliases'])
            sUrl , episoden = self.__search(titles, data['year'])
            sHtmlContent = cRequestHandler(sUrl).request()
            for episo in episoden:
            	if episode in episo:
            		return sUrl, episo
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources
            isSerie = False
            if isinstance(url, tuple):
            	isSerie = True
            	url, episode = url
            sHtmlContent = cRequestHandler(url).request()
            if isSerie:
            	pattern = '>{0}<.*?</ul></li>'.format(episode)
            	isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
            isMatch, aResult = cParser().parse(sHtmlContent, 'link="([^"]+)')
            if isMatch:
            	for sUrl in aResult:
            		if 'vod' not in sUrl and 'youtube' not in sUrl and 'streamcherry' not in sUrl:
            			if sUrl.startswith('http'): link = sUrl
            			else: link = 'https:' + str(sUrl)
            			valid, host = source_utils.is_host_valid(link, hostDict)
            			if valid: sources.append({'source': cParser.urlparse(sUrl), 'quality': '720p', 'language': 'de', 'url': link, 'direct': False, 'debridonly': False})
            return sources
        except:
        	return sources
            

    def resolve(self, url):
        return url

    def __search(self, titles, year):
         try:
            for title in titles:
            	oRequest = cRequestHandler(self.base_link)
            	oRequest.addParameters('do', 'search')
            	oRequest.addParameters('subaction', 'search')
            	oRequest.addParameters('story', title)
            	sHtmlContent = oRequest.request()
            	pattern = 'class="short">.*?href="([^"]+)">([^<]+).*?img src="([^"]+).*?desc">([^<]+).*?Jahr.*?([\d]+).*?s-red">([\d]+)'
            	isMatch, aResult = cParser().parse(sHtmlContent, pattern)
            	if not isMatch: return
            	for sUrl, sName, sThumbnail, sDesc, sYear, sDuration in aResult:
            		if not cParser().search(title, sName): continue
            		if not 'staffel' in sUrl and not 'serie' in sUrl: return sUrl
            		sHtmlContent = cRequestHandler(sUrl).request()
            		isMatch, aResult = cParser.parse(sHtmlContent, '"><a href="#">([^<]+)')
            		if not isMatch: return
            		return sUrl, aResult
         except: return