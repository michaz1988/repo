import os, io, sys, time
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,requests,zipfile,re
try:
	from BytesIO import BytesIO
except:
	from io import BytesIO
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
if PY2:
	from urllib import urlencode
	from urlparse import urlparse
	text_type = unicode
	string_types = basestring,
	integer_types = (int, long)
	text_type = unicode
	binary_type = str
	iteritems = lambda d, *args, **kwargs: d.iteritems(*args, **kwargs)
else:
	from urllib.parse import urlencode, urlparse
	text_type = str
	string_types = str,
	integer_types = int,
	binary_type = bytes
	iteritems = lambda d, *args, **kwargs: iter(d.items(*args, **kwargs))
	
def py2_uni(s, encoding='utf-8'):
	if PY2 and isinstance(s, str):
		s = unicode(s, encoding)
	return s

def py3_dec(d, encoding='utf-8'):
	if PY3 and isinstance(d, bytes):
		d = d.decode(encoding)
	return d

def py3_enc(d, encoding='utf-8'):
	if PY3 and isinstance(d, str):
		d = d.encode(encoding)
	return d

def to_str(d, encoding='utf-8'):
	if PY2:
		if not isinstance(d, basestring):
			d = str(d)
		d = d.encode(encoding) if isinstance(d, unicode) else d
	else:
		if isinstance(d, bytes):
			d = d.decode(encoding)
	return d

def read_from_file(file, mode='r'):
	if PY3:
		f = open(file, mode, encoding="utf-8")
	else:
		f = open(file, mode)
	a = f.read()
	f.close()
	return a

def write_to_file(file, content, mode='w'):
    f = open(file, mode)
    f.write(content)
    f.close()

dp           = xbmcgui.DialogProgress()
dialog 		 = xbmcgui.Dialog()
addonInfo    = xbmcaddon.Addon().getAddonInfo

AddonTitle="Tool"
AddonID ='plugin.video.tools'


def xml_data_advSettings_old(size):
	xml_data="""<advancedsettings>
</advancedsettings>""" % size
	return xml_data
	
def xml_data_advSettings_New(size):
	xml_data="""<advancedsettings>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>1</buffermode>
		<readfactor>4.0</readfactor>
	  </cache>
	  <epg>
		<displayupdatepopup>false</displayupdatepopup>
	</epg>
</advancedsettings>""" % size
	return xml_data


def write_ADV_SETTINGS_XML(file):    
    if not os.path.exists(xml_file):
        with open(xml_file, "w") as f:
            f.write(xml_data)


def advancedSettings():
	XML_FILE   =  xbmc.translatePath(os.path.join('special://home/userdata' , 'advancedsettings.xml'))
	MEM        =  xbmc.getInfoLabel("System.Memory(total)")
	FREEMEM    =  xbmc.getInfoLabel("System.FreeMemory")
	BUFFER_F   =  re.sub('[^0-9]','',FREEMEM)
	BUFFER_F   = int(BUFFER_F) / 3 *0.9
	BUFFERSIZE = BUFFER_F * 1024 * 1024
	try: KODIV        =  float(xbmc.getInfoLabel("System.BuildVersion")[:4])
	except: KODIV = 16

		
	choice = dialog.yesno('Tool','Buffer Fix:\nOptimaler Buffer bei deinem System:       ' + str(BUFFERSIZE) + ' Byte   /   ' + str(BUFFER_F) + ' MB\nWie wilst du optimieren?', yeslabel='Automatisch',nolabel='Selbst eingeben')
	
	if choice == 1: 
		with open(XML_FILE, "w") as f:
			if KODIV >= 17: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
			else: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
			
			f.write(xml_data)
			dialog.ok('Kodi','Buffer wurde auf ' + str(int(BUFFER_F)) + ' MB eingestellt.\nKodi wird beendet, damit Die Einstellung wirksam wird. Bitte neu starten.')

	
	elif choice == 0:
		BUFFERSIZE = _get_keyboard( default=str(BUFFERSIZE), heading="Buffer In Bytes eingeben")
		with open(XML_FILE, "w") as f:
			if KODIV >= 17: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
			else: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
			f.write(xml_data)
			dialog.ok('Tools','Buffer wurde manuell eingestellt.\nKodi wird beendet, damit Die Einstellung wirksam wird. Bitte neu starten.')
	os._exit(1)
	

def open_Settings():
	open_Settings = xbmcaddon.Addon(id=AddonID).openSettings()
	
def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return str( keyboard.getText())
    return default

    
def get_date(days=0, formatted=False):
    value = time.time() + (days * 24 * 60 * 60)  # days * 24h * 60m * 60s
    return value if not formatted else time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(value))
    
def get_size(path, total=0):
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total += os.path.getsize(fp)
    return total

def percentage(part, whole):
    return 100 * float(part)/float(whole)
    
def convert_size(num, suffix='B'):
    for unit in ['', 'K', 'M', 'G']:
        if abs(num) < 1024.0:
            return "%3.02f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.02f %s%s" % (num, 'G', suffix)
    
def file_count(home, excludes=True):
    item = []
    for base, dirs, files in os.walk(home):
        if excludes:
            dirs[:] = [d for d in dirs if d not in CONFIG.EXCLUDE_DIRS]
            files[:] = [f for f in files if f not in CONFIG.EXCLUDE_FILES]
        for file in files:
            item.append(file)
    return len(item)
    
def clean_house(folder, ignore=False):
    from resources.libs.common import logging

    logging.log(folder)
    total_files = 0
    total_folds = 0
    for root, dirs, files in os.walk(folder):
        if not ignore:
            dirs[:] = [d for d in dirs if d not in CONFIG.EXCLUDES]
        file_count = 0
        file_count += len(files)
        if file_count >= 0:
            for f in files:
                try:
                    os.unlink(os.path.join(root, f))
                    total_files += 1
                except:
                    try:
                        shutil.rmtree(os.path.join(root, f))
                    except:
                        logging.log("Error Deleting {0}".format(f), level=xbmc.LOGERROR)
            for d in dirs:
                total_folds += 1
                try:
                    shutil.rmtree(os.path.join(root, d))
                    total_folds += 1
                except:
                    logging.log("Error Deleting {0}".format(d), level=xbmc.LOGERROR)
    return total_files, total_folds
    

def load_zip_content(url,timeout=60):

	try:

		req = requests.get(url,stream=True,timeout=timeout)
		if req.status_code == 200:

			dp = xbmcgui.DialogProgress()
			dp.create('[COLOR blue]DOWNLOAD ZIP CONTENT[/COLOR]','Loading data !\nPlease wait ...')
			dp.update(0)

			bytes = BytesIO()
			content_bytes_len = int(req.headers.get('Content-Length'))
			chunk_len= content_bytes_len/100

			while True:

				chunk = req.raw.read(1024*16)
				if not chunk:break

				chunk_len += len(chunk)
				bytes.write(chunk)
				try:
					percent = min(chunk_len * 100 / content_bytes_len ,100)
					dp.update(percent)
				except:pass

				if dp.iscanceled():
					dp.close()
					sys.exit(0)

			dp.close()
			return bytes

	except Exception as exc:
		xbmcgui.Dialog().ok('[COLOR red]DOWNLOAD ZIP CONTENT ERROR[/COLOR]',str(exc))
		sys.exit(0)

def extract_zip(bytes,extract_path,zip_pwd=None,save_list_array=[]):

	try:

		dp = xbmcgui.DialogProgress()
		dp.create('[COLOR blue]EXTRACT ZIP[/COLOR]\nUnpacking data !\nPlease wait ...')
		dp.update(0)
	
		zip = zipfile.ZipFile(bytes,mode='r',compression=zipfile.ZIP_STORED)

		count = int(0)
		list_len = len(zip.infolist())
		for item in zip.infolist():

			count += 1
			try:
				percent = min(count * 100 / list_len ,100)
				dp.update(percent)
			except:pass

			if not any((x in item.filename for x in save_list_array)):
				try:zip.extract(item,path=extract_path,pwd=zip_pwd)
				except:pass

			if dp.iscanceled():
				zip.close()
				dp.close()
				sys.exit(0)

		zip.close()
		dp.close()

	except Exception as exc:
		xbmcgui.Dialog().ok('[COLOR red]EXTRACT ZIP ERROR[/COLOR]',str(exc))
		sys.exit(0)