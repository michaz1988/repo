# -*- coding: utf-8 -*-

import io
import os
import sys
import time
import zipfile
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
import shutil
import requests
import platform
PY2 = sys.version_info[0] == 2
V32 = str(platform.architecture()[0]) == '32bit'
transPath = xbmc.translatePath if PY2 else xbmcvfs.translatePath

ADDON = xbmcaddon.Addon()

def convert_size(num, suffix='B'):
    for unit in ['', 'K', 'M', 'G']:
        if abs(num) < 1024.0:
            return "%3.02f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.02f %s%s" % (num, 'G', suffix)

class Downloader:
	def __init__(self):
		self.dialog = xbmcgui.Dialog()
		self.progress_dialog = xbmcgui.DialogProgress()
		
	def download(self, url, place=None):
		self.progress_dialog.create("TOOLS", "Starte Download...")
		self.progress_dialog.update(0)
		f = io.BytesIO() if place == None else open(place, 'wb')
		response = requests.get(url, headers={'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36'' (KHTML, like Gecko) Chrome/35.0.1916.153 Safari''/537.36 SE 2.X MetaSr 1.0'}, stream=True)
		total = response.headers.get('content-length')
		if total is None:
			f.write(response.content)
		else:
			downloaded = 0
			total = int(total)
			start_time = time.time()
			mb = 1024*1024
			for chunk in response.iter_content(chunk_size=max(int(total/512), mb)):
				downloaded += len(chunk)
				f.write(chunk)
				done = int(100 * downloaded / total)
				kbps_speed = downloaded / (time.time() - start_time)
				if kbps_speed > 0 and not done >= 100:
					eta = (total - downloaded) / kbps_speed
				else:
					eta = 0
				kbps_speed = kbps_speed / 1024
				type_speed = 'KB'
				if kbps_speed >= 1024:
					kbps_speed = kbps_speed / 1024
					type_speed = 'MB'
				line1 = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('white', 'limegreen', downloaded / mb, 'limegreen', total / mb)
				line2 = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('white', 'limegreen', kbps_speed, type_speed)
				div = divmod(eta, 60)
				line3 = '[B]ETA:[/B] [COLOR %s]%02d:%02d[/COLOR][/COLOR]' % ('limegreen', div[0], div[1])
				if PY2:self.progress_dialog.update(done, line1, line2, line3)
				else:self.progress_dialog.update(done, line1+"\n"+line2+"\n"+line3)
		return f

class Unpacker:
	def __init__(self):
		self.dialog = xbmcgui.Dialog()
		self.progress_dialog = xbmcgui.DialogProgress()
	
	def unpack(self, _in, _out):
		self.progress_dialog.create("TOOLS", "Entpacken läuft...")
		self.progress_dialog.update(0)
		count = 0
		size = 0
		zin = zipfile.ZipFile(_in,  'r')
		nFiles = float(len(zin.namelist()))
		zipsize = convert_size(sum([item.file_size for item in zin.infolist()]))
		for item in zin.infolist():
			count += 1
			prog = int(count / nFiles * 100)
			size += item.file_size
			line1 = '[COLOR {0}][B]File:[/B][/COLOR] [COLOR {1}]{2}/{3}[/COLOR] '.format('white','limegreen',count,int(nFiles))
			line2 = '[COLOR {0}][B]Size:[/B][/COLOR] [COLOR {1}]{2}/{3}[/COLOR]'.format('white','limegreen',convert_size(size),zipsize)
			line3 = '[COLOR {0}]{1}[/COLOR]'.format('limegreen', str(item.filename).split('/')[-1])
			zin.extract(item, _out)
			if PY2:self.progress_dialog.update(prog, line1, line2, line3)
			else:self.progress_dialog.update(prog, line1+"\n"+line2+"\n"+line3)
		return True

def get_packages():
	if PY2:
		build = ADDON.getSetting('kodi18')
	else:
		build = ADDON.getSetting('kodi19')
	#if V32 and PY2:
		#build = ADDON.getSetting('kodi1832')
	#elif V32 and not PY2:
		#build = ADDON.getSetting('kodi1932')
	#elif PY2 and not V32:
		#build = ADDON.getSetting('kodi1864')
	#else:
		#build = ADDON.getSetting('kodi1964')
	data = Downloader().download(build)
	if Unpacker().unpack(data, transPath('special://home/')) == True:
		os._exit(1)