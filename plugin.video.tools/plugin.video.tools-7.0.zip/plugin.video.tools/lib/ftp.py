# uncompyle6 version 3.6.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.17 (default, Oct 23 2019, 08:25:46) 
# [GCC 4.2.1 Compatible Android (5220042 based on r346389c) Clang 8.0.7 (https://
# Embedded file name: ./lib/ftp.py
# Compiled at: 2018-10-03 02:01:50
import xbmc, xbmcgui, threading, xbmcaddon, time
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
import subprocess, re, os
from random import randint
import socket
addon = xbmcaddon.Addon()
addonPath = addon.getAddonInfo('path')
WINDOW_HOME = xbmcgui.Window(10000)


def localize(id):
    return xbmc.getLocalizedString(id)

def getPlatformName():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    if xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    if xbmc.getCondVisibility('system.platform.windows'):
        return 'win32'
    if xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    if xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    if xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    else:
        return 'unknown'


def get(key):
    return WINDOW_HOME.getProperty(key)

def xbmcNotify(heading, message, icon=xbmcgui.NOTIFICATION_ERROR):
    xbmcgui.Dialog().notification(heading=heading, message=message, icon=icon)


class ForceWindowThread(threading.Thread):

    def __init__(self, fw):
        threading.Thread.__init__(self)
        self.fw = fw
        self.setDaemon(True)
        self.start()

    def run(self):
        while not xbmc.abortRequested and self.fw.currentWindow and get('Locked') == 'true':
            winId = xbmcgui.getCurrentWindowId()
            if winId < 13000 or winId >= 14000:
                self.fw.onAction(None)
            xbmc.sleep(100)

        return


class ForceWindow(object):
    currentWindow = 0
    last = 0

    def onAction(self, action):
        winId = xbmcgui.getCurrentWindowId()
        xbmc.log('Current window %s, currentWindow window %s' % (winId, self.currentWindow))
        if self.currentWindow and self.currentWindow != winId:
            xbmc.log('Forcing window from %s to %s' % (winId, self.currentWindow))
            xbmc.executebuiltin('ReplaceWindow(%s)' % self.currentWindow)

    def onClose(self):
        if xbmcgui.getCurrentWindowId() == self.currentWindow:
            self.currentWindow = 0

    def create(self, cls, *args, **kwargs):
        xbmc.log('Creating window %r' % cls)
        diff = 0.5 - (time.time() - self.last)
        if diff > 0:
            time.sleep(diff)
        self.last = time.time()
        setProperties = kwargs.pop('setProperties', None)
        window = cls.create(*args, **kwargs)
        if setProperties:
            for key, value in list(setProperties.items()):
                window.setProperty(key, value)

        lastWindow = self.showNotModal(window)
        try:
            return window.doModal()
        finally:
            self.closeNotModal(lastWindow)

        del window
        return

    def showNotModal(self, window=None):
        lastWindow = self.currentWindow
        if window is not None:
            self.currentWindow = 0
            window.show()
        self.currentWindow = xbmcgui.getCurrentWindowId()
        if get('Locked') == 'true':
            ForceWindowThread(self)
        return lastWindow

    def closeNotModal(self, lastWindow):
        self.currentWindow = lastWindow


forceWindow = ForceWindow()

def getLocalIP():
    platform = getPlatformName()
    ip_app = None
    if platform in ('android'):
        ip_app = '/system/bin/ip'
    else:
        if platform == 'linux':
            ip_app = '/sbin/ip'
        else:
            if platform in ('win32', 'ios'):
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                try:
                    s.connect(('1.2.3.4', 80))
                    return [
                     s.getsockname()[0]]
                finally:
                    s.close()

    if ip_app:
        ips = subprocess.check_output([ip_app, 'addr']).strip()
        ips = re.findall('inet ([^/]+)', str(ips))
    else:
        raise ValueError('Unknown system %r, cannot get local IP addresses' % platform)
    ips = [ y for y in [x.strip() for x in ips] if y and not y.startswith('127.') ]
    if not ips:
        raise ValueError('Failed getting local IP adresses')
    return ips


class FtpThread(threading.Thread):

    def __init__(self, server):
        super(FtpThread, self).__init__()
        self.setDaemon(True)
        self.server = server

    def run(self):
        try:
            self.server.serve_forever()
        except Exception as e:
            xbmc.log('Failed running FTP server: %r' % e, xbmc.LOGERROR)


class MyAuthorizer(DummyAuthorizer):

    def validate_authentication(self, username, password, handler):
        handler.username = 'anonymous'
        DummyAuthorizer.validate_authentication(self, handler.username, password, handler)


class FtpWindow(xbmcgui.WindowXML):
    CANCEL_BUTTON_ID = 301
    server = None

    @classmethod
    def create(cls):
        return cls('ftp.xml', addonPath, 'Main', '1080i')

    def get_path_vavoo(self):
        return self.get_path_android()

    def get_path_android(self):
        return '/sdcard/'

    def onInit(self):
        try:
            for i, ip in enumerate(getLocalIP()):
                self.setProperty('LocalIP' + str(i), ip)

            if getPlatformName() in ('vavoo', 'android'):
                path = '/sdcard'
            else:
                path = os.path.expanduser('~')
            vavooPath = os.path.join(path, 'VAVOO')
            if not os.path.exists(vavooPath):
                try:
                    os.mkdirs(vavooPath)
                except Exception:
                    pass

            if os.path.exists(vavooPath):
                path = vavooPath
            authorizer = MyAuthorizer()
            authorizer.add_anonymous(path, perm='elradfmw')
            handler = FTPHandler
            handler.authorizer = authorizer
            ports = [
             3721, 3722, 3723, 3724, 3725, randint(1024, 65535), randint(1024, 65535)]
            for port in ports:
                try:
                    self.server = FTPServer(('0.0.0.0', port), handler)
                except Exception as e:
                    xbmc.log('Failed starting FTP on port %s: %r' % (port, e), xbmc.LOGERROR)
                    self.server = None
                else:
                    break

            if self.server is None:
                xbmcNotify(localize(257), localize(39525))
                self.close()
                return
            self.setProperty('Port', str(port))
            self.setProperty('Started', 'true')
            FtpThread(self.server).start()
        except Exception as e:
            xbmc.log('Failed starting FTP server: %r' % e, xbmc.LOGERROR)
            import traceback
            traceback.print_exc()
            xbmcNotify(localize(257), localize(39526))
            self.close()

        return

    def onClick(self, controlID):
        if controlID == self.CANCEL_BUTTON_ID:
            self.close()

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.close()
        forceWindow.onAction(action)

    def close(self):
        forceWindow.onClose()
        super(FtpWindow, self).close()

    def doModal(self):
        try:
            return xbmcgui.WindowXML.doModal(self)
        finally:
            if self.server:
                self.server.close_all()


def show():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    forceWindow.create(FtpWindow)