import xbmc, xbmcaddon
import base64
import hashlib
import binascii
import json
import requests
ADDON = xbmcaddon.Addon()
from xml.dom import minidom
from xml.dom.minidom import Element, Document


def get_element_text(elem):
    return " ".join(t.nodeValue for t in elem.childNodes if t.nodeType == t.TEXT_NODE)


def get_child_text(elem, node_name):
    children = elem.getElementsByTagName(node_name)
    if children:
        return get_element_text(children[0])
    return None


def elements_dictionary(elem):
    ret = {}
    for node in elem.childNodes:
        if node.nodeType == node.ELEMENT_NODE:
            n = node.nodeName
            if n in ret:
                ret[n] += 1
            else:
                ret[n] = 0

    ret = dict((k, [] if v > 1 else None) for k, v in list(ret.items()))
    return ret


def get_dictionary_from_children(elem):

    ret = elements_dictionary(elem)

    for node in elem.childNodes:
        if node.nodeType == node.ELEMENT_NODE:
            n = node.nodeName
            if ret[n] is None:
                ret[n] = get_dictionary_from_children(node)
            elif isinstance(ret[n], list):
                ret[n].append(get_dictionary_from_children(node))
            else:
                ret[n] = get_dictionary_from_children(node)

    if not ret:
        ret = get_element_text(elem)
    return ret


def parse_xml_string(xml_string):
    return minidom.parseString(xml_string)


def dict_to_xml(data):
    if not data:
        return ''

    def add_children(doc, parent, input_data):
        if isinstance(input_data, dict):
            for k, v in list(input_data.items()):
                child = doc.createElement(k)
                parent.appendChild(child)
                add_children(doc, child, v)
        elif isinstance(input_data, (list, tuple)):
            for item in input_data:
                add_children(doc, parent, item)
        else:
            child = doc.createTextNode(str(input_data))
            parent.appendChild(child)

    document = Document()
    key = list(data.keys())[0]
    root = document.createElement(key)
    document.appendChild(root)
    add_children(document, root, data[key])
    return document.toxml(encoding='utf8')


MODEM_HOST = ADDON.getSetting('routerip')

class ApiCtx(object):

    def __init__(self, modem_host=None):
        self.session_id = None
        self.logged_in = False
        self.login_token = None
        self.tokens = []
        self.__modem_host = modem_host if modem_host else MODEM_HOST

    def __unicode__(self):
        return '<{} modem_host={}>'.format(
            self.__class__.__name__,
            self.__modem_host
        )

    def __repr__(self):
        return self.__unicode__()

    def __str__(self):
        return self.__unicode__()

    @property
    def api_base_url(self):
        return 'http://{}/api'.format(self.__modem_host)

    @property
    def token(self):
        if not self.tokens:
            logger.warning('You ran out of tokens. You need to login again')
            return None
        return self.tokens.pop()





def check_error(elem):
    if elem.nodeName != "error":
        return None

    return {
        "type": "error",
        "error": {
            "code": get_child_text(elem, "code"),
            "message": get_child_text(elem, "message")
        }
    }


def api_response(r):
    if r.status_code != 200:
        r.raise_for_status()

    xmldoc = parse_xml_string(r.text)

    err = check_error(xmldoc.documentElement)
    if err:
        return err

    return {
        "type": "response",
        "response": get_dictionary_from_children(xmldoc.documentElement)
    }


def check_response_headers(resp, ctx):
    if '__RequestVerificationToken' in resp.headers:
        toks = [x for x in resp.headers['__RequestVerificationToken'].split("#") if x != '']
        if len(toks) > 1:
            ctx.tokens = toks[2:]
        elif len(toks) == 1:
            ctx.tokens.append(toks[0])

    if 'SessionID' in resp.cookies:
        ctx.session_id = resp.cookies['SessionID']


def post_to_url(url, data, ctx = None, additional_headers = None, proxy=None):
    cookies = build_cookies(ctx)
    headers = common_headers()

    if additional_headers:
        headers.update(additional_headers)

    r = requests.post(url, data=data, headers=headers, cookies=cookies, proxies=proxy)
    check_response_headers(r, ctx)
    return api_response(r)


def get_from_url(url, ctx = None, additional_headers = None,
                 timeout = None, proxy=None):
    cookies = build_cookies(ctx)
    headers = common_headers()

    if additional_headers:
        headers.update(additional_headers)
    r = requests.get(url, headers=headers, cookies=cookies, timeout=timeout, proxies=proxy)
    check_response_headers(r, ctx)
    return api_response(r)


def build_cookies(ctx):
    cookies = None
    if ctx and ctx.session_id:
        cookies = {
            'SessionID': ctx.session_id
        }
    return cookies


def common_headers():
    return {
        "X-Requested-With": "XMLHttpRequest"
    }

def get_session_token_info(base_url = None, proxy=None):
    """
    Get session token information

    :param base_url: base url for the modem api
    :return:
    """
    if base_url is None:
        logger.warning(
            'calling %s.get_session_token_info without base_url argument is deprecated',
            __name__
        )
        base_url = 'http://{}/api'.format(MODEM_HOST)
    url = "{}/webserver/SesTokInfo".format(base_url)
    return get_from_url(url, proxy=proxy, timeout=30)

XML_TEMPLATE = """
    <?xml version:"1.0" encoding="UTF-8"?>
    <request>
        <NetworkMode>{enable}</NetworkMode>
        <NetworkBand>3FFFFFFF</NetworkBand>
        <LTEBand>7FFFFFFFFFFFFFFF</LTEBand>
    </request>
    """.format

def connect_mobile(ctx, proxy=None):
    return switch_mobile_on(ctx, proxy=proxy)


def disconnect_mobile(ctx, proxy=None):
    return switch_mobile_off(ctx, proxy=proxy)


def get_mobile_status(ctx, proxy=None):
    url = "{}/net/net-mode".format(ctx.api_base_url)
    result = get_from_url(url, ctx, proxy=proxy)
    if result and result.get('type') == 'response':
        response = result['response']
        if response and response.get('dataswitch') == '1':
            return 'CONNECTED'
        if response and response.get('dataswitch') == '0':
            return 'DISCONNECTED'
    return 'UNKNOWN'


def switch_mobile_off(ctx, proxy=None):
    data = XML_TEMPLATE(enable=('02'))
    headers = {
        '__RequestVerificationToken': ctx.token,
    }
    url = "{}/net/net-mode".format(ctx.api_base_url)
    return post_to_url(url, data, ctx, additional_headers=headers, proxy=proxy)


def switch_mobile_on(ctx, proxy=None):
    data = XML_TEMPLATE(enable=('03'))
    headers = {
        '__RequestVerificationToken': ctx.token,
    }
    url = "{}/net/net-mode".format(ctx.api_base_url)
    return post_to_url(url, data, ctx, additional_headers=headers, proxy=proxy)


def b64_sha256(data):
    s256 = hashlib.sha256()
    s256.update(data.encode('utf-8'))
    dg = s256.digest()
    hs256 = binascii.hexlify(dg)
    return base64.urlsafe_b64encode(hs256).decode('utf-8', 'ignore')


def quick_login(username, password, modem_host = None, proxy=None):
    ctx = ApiCtx(modem_host=modem_host)
    token = get_session_token_info(ctx.api_base_url, proxy=proxy)
    session_token = token['response']['SesInfo'].split("=")
    ctx.session_id = session_token[1] if len(session_token) > 1 else session_token[0]
    ctx.login_token = token['response']['TokInfo']
    response = login(ctx, username, password, proxy=proxy)
    if not ctx.logged_in:
        raise ValueError(json.dumps(response))
    return ctx


def login(ctx, user_name, password, proxy=None):
    headers = common_headers()
    url = "{}/user/login".format(ctx.api_base_url)

    password_value = b64_sha256(user_name + b64_sha256(password) + ctx.login_token)

    xml_data = """
    <?xml version:"1.0" encoding="UTF-8"?>
    <request>
        <Username>{}</Username>
        <Password>{}</Password>
        <password_type>4</password_type>
    </request>
    """.format(user_name, password_value)

#   setup headers
    headers['__RequestVerificationToken'] = ctx.login_token
    headers['X-Requested-With'] = 'XMLHttpRequest'
    r = post_to_url(url, xml_data, ctx, headers, proxy=proxy)

    if r['type'] == "response" and r['response'] == "OK":
        ctx.logged_in = True

    return r


def state_login(ctx, proxy=None):
    url = "{}/user/state-login".format(ctx.api_base_url)
    return get_from_url(url, ctx, proxy=proxy)
