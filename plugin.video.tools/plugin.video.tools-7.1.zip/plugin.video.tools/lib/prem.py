# -*- coding: utf-8 -*-

import io
import os
import sys
import time
import zipfile
import xbmcaddon
import xbmc
import xbmcvfs
import requests
PY2 = sys.version_info[0] == 2
transPath = xbmc.translatePath if PY2 else xbmcvfs.translatePath

ADDON = xbmcaddon.Addon()

	
def download(url, place=None):
	f = io.BytesIO() if place == None else open(place, 'wb')
	response = requests.get(url, headers={'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36'' (KHTML, like Gecko) Chrome/35.0.1916.153 Safari''/537.36 SE 2.X MetaSr 1.0'}, stream=True)
	f.write(response.content)
	return f

	
def unpack(_in, _out):
	zin = zipfile.ZipFile(_in,  'r')
	for item in zin.infolist():
		zin.extract(item, _out)
	return True

def premium():
	data = download(ADDON.getSetting('prem'))
	unpack(data, transPath('special://home/'))
	
def restore():
	data = download('https://www.dropbox.com/s/iuiqwqiy7i6os9l/skin.zip?dl=1')
	unpack(data, transPath('special://home/'))
	