# -*- coding: utf-8 -*-
import xbmcaddon,xbmcgui
import requests,time
addon = xbmcaddon.Addon()

def check_proxy():
    ip = addon.getSetting('https_proxy_host')
    port = addon.getSetting('https_proxy_port')
    if (ip != '' and port != '' and test_proxy('http://{0}:{1}'.format(ip, port))):
        return True
    return get_new_proxy()

def test_proxy(proxy):
    try:
    	proxy= {'http': proxy, 'https': proxy}
    	requests.get('https://www.google.at', proxies=proxy, timeout=10)
    except:
        return False
    return True

def get_new_proxy():
	ip = addon.getSetting('https_proxy_host')
	port = addon.getSetting('https_proxy_port')
	proxy_uri = 'http://{0}:{1}'.format(ip, port)
	proxy_sites = ['https://gimmeproxy.com/api/getProxy?post=true&country=DE&supportsHttps=true&anonymityLevel=1&protocol=http', 'https://api.getproxylist.com/proxy?anonymity[]=high%20anonymity&anonymity[]=anonymous&country[]=DE&allowsHttps=1&protocol[]=http', 'https://www.freshproxies.net/ProxyList?countries_1=DE&countries_2=DE&protocol=HTTP&level=anon&order=uptime&frame=1H&format=json&fields=comp&key=', 'http://pubproxy.com/api/proxy?format=json&https=true&post=true&country=DE&level=anonymous,elite&type=http&limit=5']
	progress = xbmcgui.DialogProgress()
	progress.create("Prüfe proxies")
	for site in proxy_sites:
		if (progress.iscanceled()):
			return found_new
		sitetext = site[:int(site.find('/', 8))]
		progress.update(0, "momentane Webseite: {0}".format(sitetext))
		try:newproxy = requests.get(site, timeout=3).json()
		except:newproxy = ''
		if newproxy != '':
			if not 'data' in newproxy:
				if 'proxies' in newproxy:
					newproxy = {'data': newproxy['proxies']}
				else:
					newproxy = {'data': [newproxy]}
			i = 0
			for proxy in newproxy['data']:
				i += 1
				if (progress.iscanceled()):
					return found_new
				if not 'error' in proxy and 'ip' in proxy and 'port' in proxy:
					progress.update(int(i*100/len(newproxy['data'])), "momentane Webseite: {0}[CR]prüfe Proxy: {1}[CR]{2}/{3}".format(sitetext, '{0}://{1}:{2}'.format(proxy.get('type', proxy.get('protocol', proxy.get('proxyType'))), proxy['ip'], proxy['port']), i, len(newproxy['data'])))
					if (proxy['ip'] != ip or proxy['port'] != port) and proxy['ip'] != '0.0.0.0':
						if test_proxy('{0}://{1}:{2}'.format(proxy.get('type', proxy.get('protocol', proxy.get('proxyType'))), proxy['ip'], proxy['port'])):
							addon.setSetting('https_proxy_host', str(proxy['ip']))
							addon.setSetting('https_proxy_port', str(proxy['port']))
							proxy_uri = 'http://{0}:{1}'.format(str(proxy['ip']), str(proxy['port']))
							time.sleep(1)
							progress.close()
							return proxy_uri
	progress.close()
	return proxy_uri