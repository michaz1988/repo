import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import sys,os
import time, datetime


servicing = False

def Service():
    global servicing
    if servicing:
        return
    servicing = True
    import plugin
    plugin.setup()
    time.sleep(2)
    servicing = False

if __name__ == '__main__':
	try:
		monitor = xbmc.Monitor()
		addon = xbmcaddon.Addon()
		while not monitor.abortRequested():
			if addon.getSetting('service.type') == '3' or xbmcvfs.exists('special://profile/addon_data/plugin.video.tools/settings.xml') == False:
				Service()
				addon.setSetting('last.update', str(time.time()))
			elif addon.getSetting('service.type') == '1':
				interval = int(addon.getSetting('service.interval'))
				waitTime = 3600 * interval
				ts = addon.getSetting('last.update') or "0.0"
				lastTime = datetime.datetime.fromtimestamp(float(ts))
				now = datetime.datetime.now()
				nextTime = lastTime + datetime.timedelta(seconds=waitTime)
				td = nextTime - now
				timeLeft = td.seconds + (td.days * 24 * 3600)
			elif addon.getSetting('service.type') == '2':
				next_time = addon.getSetting('service.time')
				hms = next_time.split(':')
				hour = hms[0]
				minute = hms[1]
				now = datetime.datetime.now()
				next_time = now.replace(hour=int(hour),minute=int(minute),second=0,microsecond=0)
				if next_time < now:
					next_time = next_time + datetime.timedelta(hours=24)
				td = next_time - now
				timeLeft = td.seconds + (td.days * 24 * 3600)
			if timeLeft <= 0:
				timeLeft = 1
			xbmc.log("[plugin.video.tools] Service waiting for %d seconds" % timeLeft, xbmc.LOGINFO)
			if timeLeft and monitor.waitForAbort(timeLeft):
				break
			xbmc.log("[plugin.video.tools] Service now triggered...", xbmc.LOGINFO)
			Service()
			#addon.setSetting('last.update', str(time.time()))
	except:
		pass